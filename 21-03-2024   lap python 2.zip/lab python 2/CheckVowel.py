#cheak vowel
ch = input ("Enter a character :")

# check if ch is an alphabet or not 
# print("Enter a Character: ")
if ch>='a' and ch<='z':
    print("\nIt is an alphabet")
elif ch>='A' and ch<='z':
    print("\nIt is an alphabet")
else:
    print("\nIt is not an alphabet!")


if ch =='a' or ch =='e' or ch =='i' or ch =='o' or ch =='u':
    print("it is a vowel")
else:
    print("it is not a vowel")