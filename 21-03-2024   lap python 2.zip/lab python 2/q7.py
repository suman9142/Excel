#input amount
amt=int(input("Enter amount : "))

# check the denomination of the amount
# amount : 13900%100=0
if amt%50==0:  # true
	if amt>=2000:
		#divide amt with 2000 to get number of notes in 2000
		notes=int(amt/2000)   #  13900/2000=6

		# show number of notes for 2000
		print("2000 X "+str(notes)+" : "+str(notes*2000))  
		#  2000 X 6 : 12000
		#subtract amount(2000 notes*2000) from actual amount
		amt=amt-(notes*2000)
		#amt=13900-(6*2000)= 13900-12000=1900
	if amt>=500:
		#divide amt with 2000 to get number of notes in 2000
		notes=int(amt/500)

		# show number of notes for 500
		print("500 X "+str(notes)+" : "+str(notes*500))
		#subtract amount(500 notes*500) from actual amount
		amt=amt-(notes*500)
	if amt>=200:
		#divide amt with 200 to get number of notes in 200
		notes=int(amt/200)

		# show number of notes for 200
		print("200 X "+str(notes)+" : "+str(notes*200))
		#subtract amount(200 notes*200) from actual amount
		amt=amt-(notes*200)
	if amt>=100:
		#divide amt with 100 to get number of notes in 100
		notes=int(amt/100)

		# show number of notes for 2000
		print("100 X "+str(notes)+" : "+str(notes*100))
		#subtract amount(100 notes*100) from actual amount
		amt=amt-(notes*100)
	if amt>=50:
		#divide amt with 50 to get number of notes in 50
		notes=int(amt/50)

		# show number of notes for 50
		print("50 X "+str(notes)+" : "+str(notes*50))
		#subtract amount(50 notes*50) from actual amount
		amt=amt-(notes*50)
else:
	print("Amount should be multiple of 50!")