#Cheack even or odd number
int(input("enter an interger:"))
# odd=int(input("enter an interger:"))

ans = "Even" if ("even % 2 ==0") else "odd"

print(ans)
