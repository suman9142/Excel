print("Enter a Character: ")
c = input()
if c>='a' and c<='z':
    print("\nIt is an alphabet")
elif c>='A' and c<='z':
    print("\nIt is an alphabet")
else:
    print("\nIt is not an alphabet!")